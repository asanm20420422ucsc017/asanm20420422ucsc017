# Define the base class Player
class Player:
    def play(self):
        print("The player is playing cricket.")

# Define the derived class Batsman
class Batsman(Player):
    def play(self):
        print("The batsman is batting.")

# Define the derived class Bowler
class Bowler(Player):
    def play(self):
        print("The bowler is bowling.")

# Create objects of Batsman and Bowler classes
batsman = Batsman()
bowler = Bowler()

# Call the play() method for each object
batsman.play()
bowler.play() # defining BankAccount class

class BankAccount:
    def __init__(self,amount):
        self.__balance = amount

    def deposit(self,amount):
        self.__balance += amount

    def withdraw(self,amount):
        if self.__balance >= amount:
            self.__balance -= amount
        else:
            print('Insufficient balance')

    def get_balance(self):
        return self.__balance


# Create BankAccount object and perform operations

amount = int(input('Enter the initial amount to open your account: ')) 
account = BankAccount(amount)
print('Your balance is', account.get_balance())

amount = int(input('Enter amount to deposit: '))
account.deposit(amount)
print('Your balance is', account.get_balance())

amount = int(input('Enter amount to withdraw: '))
account.withdraw(amount)
print('Your balance is', account.get_balance())